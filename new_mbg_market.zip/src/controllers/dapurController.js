// src/controllers/dapurController.js
const pool = require('../models/db');

// =================== DASHBOARD ===================
exports.dashboard = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const [orders] = await pool.query(
      'SELECT id, total, status, created_at FROM orders WHERE user_id=? ORDER BY created_at DESC LIMIT 5',
      [userId]
    );

    // Dapur cuma lihat status high-level (awaiting_yayasan / approved / rejected / completed)
    res.render('dapur/dashboard', {
      title: 'Dashboard Dapur',
      recentOrders: orders
    });
  } catch (err) {
    console.error(err);
    req.flash('error', 'Gagal membuka dashboard');
    res.redirect('/');
  }
};

// =================== CART ===================
exports.viewCart = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const [carts] = await pool.query('SELECT * FROM carts WHERE user_id=?', [userId]);

    if (!carts.length) {
      return res.render('dapur/cart', {
        title: 'Keranjang',
        cart: { items: [] }
      });
    }

    const cartId = carts[0].id;
    const [items] = await pool.query(
      `SELECT ci.id, ci.qty, ci.price_at, p.name as product_name
       FROM cart_items ci
       JOIN products p ON p.id = ci.product_id
       WHERE ci.cart_id = ?`,
      [cartId]
    );

    res.render('dapur/cart', {
      title: 'Keranjang',
      cart: { items }
    });
  } catch (err) {
    console.error(err);
    req.flash('error', 'Gagal mengambil keranjang');
    res.redirect('/market');
  }
};

exports.addToCart = async (req, res) => {
  try {
    const user = req.session.user;
    if (!user || user.role !== 'dapur') {
      req.flash('error', 'Hanya dapur yang bisa memesan');
      return res.redirect('/login');
    }

    const productId = req.body.product_id;
    const qty = parseFloat(req.body.qty) || 1;

    const [prodRows] = await pool.query(
      'SELECT id, price FROM products WHERE id = ?',
      [productId]
    );
    if (!prodRows.length) {
      req.flash('error', 'Produk tidak ditemukan');
      return res.redirect('/market');
    }
    const priceAt = prodRows[0].price;

    const [carts] = await pool.query(
      'SELECT * FROM carts WHERE user_id=?',
      [user.id]
    );
    let cartId;
    if (carts.length) {
      cartId = carts[0].id;
    } else {
      const [r] = await pool.query(
        'INSERT INTO carts (user_id) VALUES (?)',
        [user.id]
      );
      cartId = r.insertId;
    }

    const [exists] = await pool.query(
      'SELECT * FROM cart_items WHERE cart_id=? AND product_id=?',
      [cartId, productId]
    );
    if (exists.length) {
      await pool.query(
        'UPDATE cart_items SET qty = qty + ? WHERE id = ?',
        [qty, exists[0].id]
      );
    } else {
      await pool.query(
        'INSERT INTO cart_items (cart_id, product_id, qty, price_at) VALUES (?,?,?,?)',
        [cartId, productId, qty, priceAt]
      );
    }

    req.flash('success', 'Produk ditambahkan ke keranjang');
    res.redirect('/market');
  } catch (err) {
    console.error(err);
    req.flash('error', 'Gagal menambahkan ke keranjang');
    res.redirect('/market');
  }
};

exports.removeFromCart = async (req, res) => {
  try {
    const itemId = req.body.item_id;
    await pool.query(
      `DELETE ci FROM cart_items ci
       JOIN carts c ON ci.cart_id = c.id
       WHERE ci.id = ? AND c.user_id = ?`,
      [itemId, req.session.user.id]
    );
    req.flash('success', 'Item dihapus dari keranjang');
    res.redirect('/dapur/cart');
  } catch (err) {
    console.error(err);
    req.flash('error', 'Gagal menghapus item');
    res.redirect('/dapur/cart');
  }
};

// =================== CHECKOUT ===================
exports.checkout = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const userId = req.session.user.id;

    const [carts] = await conn.query(
      'SELECT * FROM carts WHERE user_id=?',
      [userId]
    );
    if (!carts.length) {
      req.flash('error', 'Keranjang kosong');
      await conn.rollback();
      conn.release();
      return res.redirect('/dapur/cart');
    }
    const cartId = carts[0].id;

    const [items] = await conn.query(
      `SELECT ci.product_id, ci.qty, ci.price_at, p.yayasan_id
       FROM cart_items ci
       JOIN products p ON p.id = ci.product_id
       WHERE ci.cart_id = ?`,
      [cartId]
    );
    if (!items.length) {
      req.flash('error', 'Keranjang kosong');
      await conn.rollback();
      conn.release();
      return res.redirect('/dapur/cart');
    }

    const yayasanIds = [...new Set(items.map(x => x.yayasan_id))];
    if (yayasanIds.length > 1) {
      req.flash('error', 'Semua item harus dari yayasan yang sama');
      await conn.rollback();
      conn.release();
      return res.redirect('/dapur/cart');
    }
    const yayasanId = yayasanIds[0] || null;

    let total = 0;
    items.forEach(it => {
      total += Number(it.price_at) * Number(it.qty);
    });

    // INSERT ORDER:
    // status awal tetap yang lama: 'awaiting_yayasan'
    // (kalau mau ganti ke 'pending_yayasan', ubah di sini & di bagian yayasanController + enum DB)
    const [r] = await conn.query(
      'INSERT INTO orders (user_id, yayasan_id, total, status, created_at) VALUES (?,?,?,?,NOW())',
      [userId, yayasanId, total, 'awaiting_yayasan']
    );
    const orderId = r.insertId;

    const insertPromises = items.map(it =>
      conn.query(
        'INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?,?,?,?)',
        [orderId, it.product_id, it.qty, it.price_at]
      )
    );
    await Promise.all(insertPromises);

    if (yayasanId) {
      await conn.query(
        'INSERT INTO notifications (user_id, order_id, type, payload, created_at) VALUES (?,?,?,?,NOW())',
        [
          yayasanId,
          orderId,
          'yayasan_pending',
          JSON.stringify({ orderId, from: userId })
        ]
      );
    }

    await conn.query('DELETE FROM cart_items WHERE cart_id = ?', [cartId]);
    await conn.query('DELETE FROM carts WHERE id = ?', [cartId]);

    await conn.commit();
    conn.release();

    req.flash(
      'success',
      'Checkout berhasil — order dikirim ke yayasan untuk approval'
    );
    return res.redirect('/dapur/dashboard');
  } catch (err) {
    try {
      await conn.rollback();
    } catch (e) {
      /* ignore */
    }
    conn.release();
    console.error('checkout error:', err);
    req.flash('error', 'Gagal checkout');
    return res.redirect('/dapur/cart');
  }
};

// =================== DETAIL ORDER (DAPUR) ===================
exports.orderDetailForDapur = async (req, res) => {
  try {
    const userId = req.session.user.id;
    const orderId = Number(req.params.orderId);
    if (!orderId) {
      req.flash('error', 'Order ID tidak valid');
      return res.redirect('/dapur/dashboard');
    }

    // pastikan order milik user
    const [ordRows] = await pool.query(
      'SELECT id, total, status, created_at FROM orders WHERE id = ? AND user_id = ? LIMIT 1',
      [orderId, userId]
    );
    if (!ordRows.length) {
      req.flash('error', 'Order tidak ditemukan');
      return res.redirect('/dapur/dashboard');
    }
    const order = ordRows[0];

    // AMBIL ITEM TANPA STATUS VENDOR (dapur tidak lihat proses vendor)
    const [items] = await pool.query(
      `SELECT
         oi.id AS order_item_id,
         oi.product_id,
         oi.qty,
         oi.price,
         p.name AS product_name
       FROM order_items oi
       JOIN products p ON p.id = oi.product_id
       WHERE oi.order_id = ?
       ORDER BY oi.id`,
      [orderId]
    );

    // render view yang hanya menampilkan produk + qty + price
    return res.render('dapur/order_detail', { order, items });
  } catch (err) {
    console.error('orderDetailForDapur error:', err);
    req.flash('error', 'Gagal mengambil detail order');
    return res.redirect('/dapur/dashboard');
  }
};
