// src/controllers/vendorController.js
const pool = require('../models/db');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// ========== KONFIG UPLOAD UMUM ==========
const upload = multer({
  dest: path.join(__dirname, '../../src/public/uploads/')
});
exports.upload = upload.single('image');

const uploadShipment = multer({
  dest: path.join(__dirname, '../../src/public/uploads/shipments/')
});
exports.uploadShipment = uploadShipment.single('delivery_attachment');

// ====== FOLDER UNTUK TANDA TANGAN DAPUR (diupload OLEH VENDOR) ======
const signatureDir = path.join(__dirname, '../../src/public/uploads/signatures');
if (!fs.existsSync(signatureDir)) {
  fs.mkdirSync(signatureDir, { recursive: true });
}
const signatureUpload = multer({ dest: signatureDir });
exports.uploadSignature = signatureUpload.single('signature');

// ========== DASHBOARD ==========
exports.getDashboard = async (req, res) => {
  try {
    const vendorId = req.session.user.id;
    const [products] = await pool.query(
      'SELECT * FROM products WHERE vendor_id = ?',
      [vendorId]
    );

    // hitung pesanan vendor (vendor_order_status pending / preparing)
    const [cntRows] = await pool.query(
      'SELECT COUNT(*) AS cnt FROM vendor_order_status WHERE vendor_id = ? AND status IN (?, ?)',
      [vendorId, 'pending', 'preparing']
    );
    const pendingCount = cntRows && cntRows[0] ? cntRows[0].cnt : 0;

    return res.render('vendor/dashboard', {
      title: 'Dashboard Vendor',
      products,
      pendingCount
    });
  } catch (err) {
    console.error('getDashboard error:', err);
    req.flash('error', 'Gagal memuat dashboard vendor');
    return res.redirect('/');
  }
};

// ========== PRODUK ==========
exports.createProductForm = (req, res) => {
  res.render('vendor/create');
};

exports.createProduct = async (req, res) => {
  try {
    const vendorId = req.session.user.id;
    const yayasanId = req.session.user.yayasan_id || req.session.user.id;
    const { name, category, price, unit, stock, description } = req.body;
    const image = req.file ? '/uploads/' + req.file.filename : null;

    await pool.query(
      `INSERT INTO products
       (vendor_id, yayasan_id, name, category, price, unit, stock, description, image)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [vendorId, yayasanId, name, category, price, unit, stock, description, image]
    );

    req.flash('success', 'Produk ditambahkan');
    res.redirect('/vendor/dashboard');
  } catch (err) {
    console.error('createProduct error:', err);
    req.flash('error', 'Gagal menambah produk');
    res.redirect('/vendor/dashboard');
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const vendorId = req.session.user.id;
    const { id } = req.params;
    await pool.query(
      'DELETE FROM products WHERE id = ? AND vendor_id = ?',
      [id, vendorId]
    );
    req.flash('success', 'Produk dihapus (jika milik Anda)');
    res.redirect('/vendor/dashboard');
  } catch (err) {
    console.error('deleteProduct error:', err);
    req.flash('error', 'Gagal menghapus produk');
    res.redirect('/vendor/dashboard');
  }
};

// ========== PESANAN YANG HARUS DI-SIAPKAN ==========
exports.getOrdersToPrepare = async (req, res) => {
  try {
    const vendorId = req.session.user.id;
    // Fokus ke vendor_order_status; order.status tidak dipakai filter ketat
    const [orders] = await pool.query(
      `SELECT DISTINCT o.*
       FROM orders o
       JOIN vendor_order_status vos ON vos.order_id = o.id
       WHERE vos.vendor_id = ?
         AND vos.status IN ('pending', 'preparing')
       ORDER BY o.created_at DESC`,
      [vendorId]
    );

    return res.render('vendor/orders_to_prepare', { orders });
  } catch (err) {
    console.error('getOrdersToPrepare error:', err);
    req.flash('error', 'Gagal mengambil pesanan untuk disiapkan');
    return res.redirect('/vendor/dashboard');
  }
};

// ========== LIST PESANAN VENDOR (HANYA ITEM MILIK VENDOR) ==========
exports.getOrders = async (req, res) => {
  try {
    const vendorId = req.session.user.id;

    const [rows] = await pool.query(
      `SELECT
         vos.id AS vos_id,
         vos.order_id,
         vos.status AS vendor_status,
         o.total AS order_total,
         o.status AS order_status,
         o.user_id AS dapur_id,
         o.created_at AS order_created,
         oi.id AS order_item_id,
         oi.product_id,
         oi.qty,
         oi.price,
         p.name AS product_name
       FROM vendor_order_status vos
       JOIN orders o ON o.id = vos.order_id
       JOIN order_items oi ON oi.order_id = o.id
       JOIN products p ON p.id = oi.product_id
       WHERE vos.vendor_id = ? AND p.vendor_id = ?
       ORDER BY o.created_at DESC, oi.id`,
      [vendorId, vendorId]
    );

    const ordersMap = new Map();
    for (const r of rows) {
      if (!ordersMap.has(r.order_id)) {
        ordersMap.set(r.order_id, {
          order_id: r.order_id,
          order_total: r.order_total,
          order_status: r.order_status,
          dapur_id: r.dapur_id,
          created_at: r.order_created,
          vendor_status: r.vendor_status,
          items: []
        });
      }
      const ord = ordersMap.get(r.order_id);
      ord.items.push({
        order_item_id: r.order_item_id,
        product_id: r.product_id,
        product_name: r.product_name,
        qty: r.qty,
        price: r.price
      });
    }

    const orders = Array.from(ordersMap.values());
    return res.render('vendor/orders', { title: 'Pesanan Saya', orders });
  } catch (err) {
    console.error('getOrders error:', err);
    req.flash('error', 'Gagal mengambil pesanan');
    return res.redirect('/vendor/dashboard');
  }
};

// ========== UPDATE STATUS PESANAN VENDOR (pending -> preparing / shipped) ==========
exports.updateVendorOrderStatus = async (req, res) => {
  const vendorId = req.session.user.id;
  const orderId = req.params.orderId;
  const status = req.body.status;

  const valid = new Set(['preparing', 'shipped']);
  if (!valid.has(status)) {
    req.flash('error', 'Status tidak valid (vendor hanya boleh: Siapkan atau Dikirim)');
    return res.redirect('/vendor/orders');
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [rows] = await conn.query(
      'SELECT * FROM vendor_order_status WHERE order_id = ? AND vendor_id = ? FOR UPDATE',
      [orderId, vendorId]
    );
    if (!rows.length) throw new Error('Tidak ada pesanan ini untuk vendor Anda');

    await conn.query(
      'UPDATE vendor_order_status SET status = ?, updated_at = NOW() WHERE order_id = ? AND vendor_id = ?',
      [status, orderId, vendorId]
    );

    // Kirim notif ke YAYASAN (bukan ke dapur)
    const [ordRows] = await conn.query(
      'SELECT yayasan_id FROM orders WHERE id = ?',
      [orderId]
    );
    if (ordRows.length) {
      const yayasanId = ordRows[0].yayasan_id;
      const notifType = status === 'shipped' ? 'vendor_shipped' : 'vendor_preparing';
      await conn.query(
        'INSERT INTO notifications (user_id, order_id, type, payload, created_at) VALUES (?,?,?,?,NOW())',
        [yayasanId, orderId, notifType, JSON.stringify({ orderId, vendorId })]
      );
    }

    await conn.commit();
    conn.release();
    req.flash('success', 'Status pesanan vendor diperbarui');
    return res.redirect('/vendor/orders');
  } catch (err) {
    await conn.rollback();
    conn.release();
    console.error('updateVendorOrderStatus error:', err);
    req.flash('error', 'Gagal memperbarui status: ' + (err.sqlMessage || err.message));
    return res.redirect('/vendor/orders');
  }
};

// ========== KIRIM SURAT JALAN (PHASE 1 – VENDOR KIRIM BARANG) ==========
exports.createVendorShipment = async (req, res) => {
  const vendorId = req.session.user.id;
  const orderId = Number(req.params.orderId);

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [vos] = await conn.query(
      'SELECT * FROM vendor_order_status WHERE order_id = ? AND vendor_id = ? FOR UPDATE',
      [orderId, vendorId]
    );
    if (!vos.length) throw new Error('Order tidak terkait dengan vendor Anda');

    const vosRow = vos[0];
    if (vosRow.status === 'shipped') {
      throw new Error('Vendor sudah menandai dikirim untuk order ini');
    }

    const [ordRows] = await conn.query(
      'SELECT * FROM orders WHERE id = ? FOR UPDATE',
      [orderId]
    );
    if (!ordRows.length) throw new Error('Order tidak ditemukan');
    const order = ordRows[0];

    if (order.status === 'completed') {
      throw new Error('Order sudah completed; tidak bisa kirim lagi');
    }

    const shipped_at = req.body.shipped_at ? new Date(req.body.shipped_at) : null;
    const plate_number = req.body.plate_number || null;
    const sender_name = req.body.sender_name || null;
    const sender_contact = req.body.sender_contact || null;
    const note = req.body.note || null;

    if (!shipped_at || !plate_number || !sender_name) {
      throw new Error('Field shipped_at, plate_number, dan sender_name wajib diisi');
    }

    // FILE SEKARANG OPSIONAL
    const file = req.file;
    let attachmentPath = null;
    if (file) {
      attachmentPath = '/uploads/shipments/' + file.filename;
    }

    await conn.query(
      `INSERT INTO vendor_shipments
       (order_id, vendor_id, shipped_at, plate_number, sender_name, sender_contact, note, attachment_path, created_at)
       VALUES (?,?,?,?,?,?,?,?,NOW())
       ON DUPLICATE KEY UPDATE
         shipped_at = VALUES(shipped_at),
         plate_number = VALUES(plate_number),
         sender_name = VALUES(sender_name),
         sender_contact = VALUES(sender_contact),
         note = VALUES(note),
         attachment_path = VALUES(attachment_path),
         created_at = NOW()`,
      [orderId, vendorId, shipped_at, plate_number, sender_name, sender_contact, note, attachmentPath]
    );

    await conn.query(
      'UPDATE vendor_order_status SET status = ?, updated_at = NOW() WHERE order_id = ? AND vendor_id = ?',
      ['shipped', orderId, vendorId]
    );

    // Notif ke YAYASAN
    if (order.yayasan_id) {
      await conn.query(
        'INSERT INTO notifications (user_id, order_id, type, payload, created_at) VALUES (?,?,?,?,NOW())',
        [
          order.yayasan_id,
          orderId,
          'vendor_shipped_with_doc',
          JSON.stringify({ orderId, vendorId, attachmentPath })
        ]
      );
    }

    await conn.commit();
    conn.release();

    return res.json({
      success: true,
      message: 'Surat jalan dikirim dan status vendor diperbarui'
    });
  } catch (err) {
    await conn.rollback();
    conn.release();
    console.error('createVendorShipment error:', err);
    return res.status(400).json({
      success: false,
      error: err.message || 'Gagal submit surat jalan'
    });
  }
};


// ========== FORM TANDA TANGAN DAPUR (PHASE 2 – VENDOR MINTA TTD DAPUR) ==========
exports.getSignatureForm = async (req, res) => {
  try {
    const vendorId = req.session.user.id;
    const orderId = Number(req.params.orderId);
    if (!orderId) {
      req.flash('error', 'Order ID tidak valid');
      return res.redirect('/vendor/orders');
    }

    // Pastikan order ini memang ada item milik vendor ini
    const [rows] = await pool.query(
      `SELECT 
         o.id,
         o.total,
         o.status,
         o.created_at,
         u.name AS dapur_name
       FROM orders o
       JOIN users u ON u.id = o.user_id    -- dapur
       JOIN order_items oi ON oi.order_id = o.id
       JOIN products p ON p.id = oi.product_id
       WHERE o.id = ? AND p.vendor_id = ?
       LIMIT 1`,
      [orderId, vendorId]
    );

    if (!rows.length) {
      req.flash('error', 'Order tidak ditemukan atau bukan milik vendor Anda');
      return res.redirect('/vendor/orders');
    }

    const order = rows[0];

    return res.render('vendor/order_signature', {
      title: `Tanda Tangan Dapur — Order #${orderId}`,
      order
    });
  } catch (err) {
    console.error('getSignatureForm error:', err);
    req.flash('error', 'Gagal membuka form tanda tangan dapur');
    return res.redirect('/vendor/orders');
  }
};

// ========== SUBMIT TANDA TANGAN DAPUR (VENDOR UPLOAD VIA SIGNATURE PAD) ==========
exports.submitDapurSignature = async (req, res) => {
  const vendorId = req.session.user.id;
  const orderId = Number(req.params.orderId);

  if (!orderId) {
    req.flash('error', 'Order ID tidak valid');
    return res.redirect('/vendor/orders');
  }

  try {
    const [ordRows] = await pool.query(
      `SELECT 
         o.id,
         o.user_id   AS dapur_id,
         o.yayasan_id
       FROM orders o
       JOIN order_items oi ON oi.order_id = o.id
       JOIN products p ON p.id = oi.product_id
       WHERE o.id = ? AND p.vendor_id = ?
       LIMIT 1`,
      [orderId, vendorId]
    );

    if (!ordRows.length) {
      req.flash('error', 'Order tidak ditemukan atau bukan milik vendor Anda');
      return res.redirect('/vendor/orders');
    }

    const order = ordRows[0];

    const arrived_at = req.body.arrived_at ? new Date(req.body.arrived_at) : null;
    const receiver_name = req.body.receiver_name || null;
    const notes = req.body.notes || null;

    // 📌 EDIT CATATAN SURAT JALAN JUGA (optional)
    await pool.query(
      `UPDATE vendor_shipments
       SET note = ?, updated_at = NOW()
       WHERE order_id = ? AND vendor_id = ?`,
      [notes, orderId, vendorId]
    );

    // ====== SIGNATURE DARI CANVAS (BASE64) ======
    const signatureDataUrl = req.body.signature_data;
    if (!signatureDataUrl) {
      req.flash('error', 'Tanda tangan wajib diisi');
      return res.redirect(`/vendor/orders/${orderId}/sign`);
    }

    // expected format: "data:image/png;base64,AAAA..."
    const match = signatureDataUrl.match(/^data:image\/\w+;base64,(.+)$/);
    const base64Data = match ? match[1] : signatureDataUrl;

    const fileName = `sign-order${orderId}-${Date.now()}.png`;
    const filePathAbs = path.join(signatureDir, fileName);

    fs.writeFileSync(filePathAbs, Buffer.from(base64Data, 'base64'));

    const signaturePath = '/uploads/signatures/' + fileName;

    // Hapus konfirmasi lama
    await pool.query(
      'DELETE FROM delivery_confirmations WHERE order_id = ? AND yayasan_id = ?',
      [orderId, order.yayasan_id || null]
    );

    // Insert konfirmasi baru
    await pool.query(
      `INSERT INTO delivery_confirmations
       (order_id, user_id, yayasan_id, arrived_at, notes, receiver_name, signature_path, created_at)
       VALUES (?,?,?,?,?,?,?,NOW())`,
      [
        orderId,
        order.dapur_id,
        order.yayasan_id || null,
        arrived_at,
        notes,
        receiver_name,
        signaturePath
      ]
    );

    // Notif ke yayasan
    if (order.yayasan_id) {
      await pool.query(
        'INSERT INTO notifications (user_id, order_id, type, payload, created_at) VALUES (?,?,?,?,NOW())',
        [
          order.yayasan_id,
          orderId,
          'delivery_confirmed',
          JSON.stringify({ orderId, byVendor: vendorId })
        ]
      );
    }

    req.flash('success', 'Tanda tangan dapur berhasil disimpan & dikirim ke yayasan');
    return res.redirect('/vendor/orders');
  } catch (err) {
    console.error('submitDapurSignature error:', err);
    req.flash('error', 'Gagal menyimpan tanda tangan dapur');
    return res.redirect('/vendor/orders');
  }
};
