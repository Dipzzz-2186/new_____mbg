// src/controllers/marketplaceController.js
const pool = require('../models/db');


exports.list = async (req, res) => {
  try {
    const search = (req.query.q || '').trim();
    const user = req.session.user;
    const yayasanId = user ? (user.yayasan_id || user.id) : null;

    let sql = `
      SELECT p.*, u.name AS vendor_name
      FROM products p
      JOIN users u ON u.id = p.vendor_id
      WHERE 1 = 1
    `;
    const params = [];

    if (yayasanId) {
      sql += ' AND p.yayasan_id = ?';
      params.push(yayasanId);
    }

    if (search) {
      sql += ' AND (p.name LIKE ? OR p.category LIKE ? OR u.name LIKE ?)';
      const like = `%${search}%`;
      params.push(like, like, like);
    }

    sql += ' ORDER BY p.created_at DESC';

    const [products] = await pool.query(sql, params);

    res.render('marketplace/list', {
      title: 'Marketplace Bahan Makanan',
      products,
      currentUser: user,
      currentPage: 'market',
      searchQuery: search // biar nilai search tetap muncul di navbar
    });
  } catch (err) {
    console.error(err);
    req.flash('error', 'Gagal memuat produk');
    res.redirect('/');
  }
};

exports.list = async (req, res) => {
  try {
    const search = (req.query.q || '').trim();
    const user = req.session.user;
    const yayasanId = user ? (user.yayasan_id || user.id) : null;

    let sql = `
      SELECT p.*, u.name AS vendor_name
      FROM products p
      JOIN users u ON u.id = p.vendor_id
      WHERE 1 = 1
    `;
    const params = [];

    if (yayasanId) {
      sql += ' AND p.yayasan_id = ?';
      params.push(yayasanId);
    }

    if (search) {
      sql += ' AND (p.name LIKE ? OR p.category LIKE ? OR u.name LIKE ?)';
      const like = `%${search}%`;
      params.push(like, like, like);
    }

    sql += ' ORDER BY p.created_at DESC';

    const [products] = await pool.query(sql, params);

    res.render('marketplace/list', {
      title: 'Marketplace Bahan Makanan',
      products,
      currentUser: user,
      currentPage: 'market',
      searchQuery: search
    });
  } catch (err) {
    console.error(err);
    req.flash('error', 'Gagal memuat produk');
    res.redirect('/');
  }
};

exports.liveSearch = async (req, res) => {
  try {
    const search = (req.query.q || '').trim();
    const user = req.session.user;
    const yayasanId = user ? (user.yayasan_id || user.id) : null;

    let sql = `
      SELECT p.*, u.name AS vendor_name
      FROM products p
      JOIN users u ON u.id = p.vendor_id
      WHERE 1 = 1
    `;
    const params = [];

    if (yayasanId) {
      sql += ' AND p.yayasan_id = ?';
      params.push(yayasanId);
    }

    if (search) {
      sql += ' AND (p.name LIKE ? OR p.category LIKE ? OR u.name LIKE ?)';
      const like = `%${search}%`;
      params.push(like, like, like);
    }

    sql += ' ORDER BY p.created_at DESC';

    const [products] = await pool.query(sql, params);

    // kirim JSON, nanti dirender di front-end
    res.json({ products });
  } catch (err) {
    console.error(err);
    res.status(500).json({ products: [], error: 'Gagal melakukan pencarian' });
  }
};